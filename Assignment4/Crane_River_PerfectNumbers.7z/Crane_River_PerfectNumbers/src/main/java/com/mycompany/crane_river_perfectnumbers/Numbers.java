/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.crane_river_perfectnumbers;

import java.util.Scanner;

/**
 *
 * River Crane, last updated 1/14/20 6:21pm
 */
public class Numbers {
    public static void main(String[] args) {
        
        int number;
        Scanner input = new Scanner(System.in);
        
        //User input.
        System.out.print("Enter the largest number to try to display: ");
        number = input.nextInt();
        
        while (number >= 100000) {
            System.out.print("Please ener a number less than 100000. ");
            number = input.nextInt();
        }

       //Using isPerfect to list the perfect numbers.
       for(int i = 1; i <= number; i++) {
           if (isPerfect(i)) {
               System.out.print(i + " is perfect.\n");
               factors(i);
           }
       }
    }
     //Method named isPerfect finding the perfect numbers based on the user input.
     public static boolean isPerfect(int number) {
       int total = 0;
       for(int i = 1; i <= number / 2; i++) {
           if(number % i == 0) {
               total += i;
           }
       }
       
       if(total == number) {
           return true;
       }
       else {
           return false;
       }
    } 
     //Added a public static void to find the factors for a number.
     
         public static void factors(int args) {
             
             System.out.print("\tFactors: ");
           for(int j = 1; j <= args; j++) {
                if (args % j == 0) {
                    System.out.printf("%d ", j);
                }
           }
           System.out.printf("%n");
        }
 
}
