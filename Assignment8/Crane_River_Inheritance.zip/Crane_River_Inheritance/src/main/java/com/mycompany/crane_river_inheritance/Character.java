package com.mycompany.crane_river_inheritance;

// Character will be the superclass, creating the base layout for all other classes besides main.
public class Character {
    protected final String Name;
    protected final String Classes;
    protected final int Defence;
    protected final int Offence;
    protected final int inventorySpace;
    protected final double Experience;
    
    // 6 argument constructor
    public Character(String Name, String Classes, int Defence, int Offence, int inventorySpace, double Experience) {
        this.Name = Name;
        this.Classes = Classes;
        this.Defence = Defence;
        this.Offence = Offence;
        this.inventorySpace = inventorySpace;
        this.Experience = Experience;
        
    }
    
    // return all characteristics
    public String getName() { return Name; }
    public String getClasses() { return Classes; }
    public int getDefence() { return Defence; }
    public int getOffence () { return Offence; }
    public int getInventorySpace() { return inventorySpace; }
    public double getExperience() { return Experience; }
}
