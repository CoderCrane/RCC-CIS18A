/* Programmer Name: River Crane
 * Assignment Start: 1/28/20 8:32am - 11:36am
 * Assignment Completion: 1/28/20 11:36am
 * Total Hours for Assignment: 3 hours and 4 minutes.
 * Comments: Enjoyable assignment, and good practice. Character is the superclass of
 * Knight and Wizard, and Knight is the superclass of Squire.
 */
package com.mycompany.crane_river_inheritance;


public class Assignment8 {
    public static void main(String[] args) {
        //List attribute layout of superclass Character
        Character character = new Character("Name: ", "Class: ", 0, 0, 0, 0.0);
        
        System.out.printf("%s%n%17s%23s%n%17s%24s%n%17s%20d%n%17s%20d%n%17s%20d%n%17s%22.1f%n%n", "The following is the layout for the superclass Character:",
                character.getName(), "Name", character.getClasses(), "Class", "Defence: ", character.getDefence(), "Offence: ",
                character.getOffence(), "Inventory Space: ", character.getInventorySpace(), "Experience: ", character.getExperience() );
        
        //List Subclass Knight attributes
        Knight knight = new Knight("Name: ", "Class: ", 50, 35, 20, 45.7);
        System.out.printf("%s%n%17s%24s%n%17s%24s%n%17s%20d%n%17s%20d%n%17s%20d%n%17s%22.1f%n%n", "The following is the layout for the subclass Knight:",
                knight.getName(), "Herald", knight.getClasses(), "Knight", "Defence: ", knight.getDefence(), "Offence: ",
                knight.getOffence(), "Inventory Space: ", knight.getInventorySpace(), "Experience: ", knight.getExperience() );
        
        //List Subclass Wizard attributes
        Wizard wizard = new Wizard("Name: ", "Class: ", 28, 40, 15, 80.5);
        System.out.printf("%s%n%17s%25s%n%17s%24s%n%17s%20d%n%17s%20d%n%17s%20d%n%17s%22.1f%n%n", "The following is the layout for the subclass Wizard:",
                wizard.getName(), "Agimaex", wizard.getClasses(), "Wizard", "Defence: ", wizard.getDefence(), "Offence: ",
                wizard.getOffence(), "Inventory Space: ", wizard.getInventorySpace(), "Experience: ", wizard.getExperience() );
        
        //List attributes of Squire, which is a subclass of Knight
        Squire squire = new Squire("Name: ", "Class: ", 15, 8, 25, 24.2, 525);
        System.out.printf("%s%n%20s%25s%n%20s%24s%n%20s%20d%n%20s%19d%n%20s%20d%n%20s%22.1f%n%20s%21d%n%n", "The following is the layout for the subclass of Squire, Knight is its superclass:",
                squire.getName(), "Timothy", squire.getClasses(), "Squire", "Defence: ", squire.getDefence(), "Offence: ",
                squire.getOffence(), "Inventory Space: ", squire.getInventorySpace(), "Experience: ", squire.getExperience(), "Land owned(acres): ", squire.getAcres() );
    }
}
