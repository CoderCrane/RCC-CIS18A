package com.mycompany.crane_river_inheritance;

public class Squire extends Knight {
    protected final int Acres;
        public Squire (String Name, String Classes, int Defence, int Offence, int inventorySpace, double Experience, int Acres) {
        super(Name, Classes, Defence, Offence, inventorySpace, Experience);
        this.Acres = Acres;
    }
    public int getAcres() { return Acres; }
}
