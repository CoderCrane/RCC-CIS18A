package com.mycompany.crane_river_inheritance;

public class Wizard extends Character {
        public Wizard (String Name, String Classes, int Defence, int Offence, int inventorySpace, double Experience) {
        super(Name, Classes, Defence, Offence, inventorySpace, Experience);
    }
}
