/* Programmer Name: River Crane
 * Assignment Start: 2/3/20 10:37am - 12:44pm, 2/4/20 3:25pm - 3:44pm, 4:20pm - 4:29pm
 * Assignment Completion: 2/4/20 4:29pm
 * Total Hours for Assignment: 2 hours and 35 minutes.
 * Comments: None.
 */
package com.mycompany.crane_river_monthdays;

import java.util.Scanner;

public class MonthDaysTest {
    public static void main (String[] args) {
        Scanner input = new Scanner(System.in);
        
        int monthEntered;
        int yearEntered;

        
        System.out.printf("%s", "Enter the month(1=January, 2=February, ..., 12=December): ");
        monthEntered = input.nextInt();
        
        System.out.printf("%s", "Enter the year: ");
        yearEntered = input.nextInt();
        
        MonthDays finalDate;
        try {
            finalDate = new MonthDays(monthEntered, yearEntered);
            System.out.printf("%n%d%s%d%s%d%s", monthEntered, "/", yearEntered, " has ", finalDate.getNumberOfDays(), " days.");
        }
        catch (IllegalArgumentException exception) {
            System.out.printf("%s", exception.getMessage());
        }
        


    }
}
