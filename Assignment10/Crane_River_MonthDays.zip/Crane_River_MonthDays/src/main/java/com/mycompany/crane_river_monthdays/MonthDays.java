/* 
 * Programmer documentation in MonthDaysTest.
 */
package com.mycompany.crane_river_monthdays;

//Class named MonthDays
public class MonthDays {
    //Two paramaters constructor will use
    private int month;
    private int year;
    
    //Constructor takes two parameters: int for month and int for year, getter methods for private member vriables
    //month and year validation is included for setters to throw an exception
    public MonthDays (int month, int year) {    
        if (month > 12 || month < 1) {
            throw new IllegalArgumentException("Months must be between 1 and 12.  Program terminating.");
        }
        this.month = month;
        if (year <= 0) {
            throw new IllegalArgumentException("Year must be greater than 0.  Program terminating.");
        }
        this.year = year;
    }
    
    //getters
    public int getMonth() {
        return month;
    }
    
    public int getYear() {
        return year;
    }
      
    //setters
    public void setMonth(int month) {
        this.month = month;
    } 
    
    public void setYear(int year) {
        this.year = year;
    }
    
    //Method named getNumberOfDays
    public int getNumberOfDays() {
        int numberOfDays = 0;
    //if statements for each month based off user entered value.
    //January
    if (month == 1) {
        numberOfDays = 31;
    }
    //February, will find out if it is a leap year.
    if (month == 2) {
        //First check of leap year, divisable by 100 AND 400
        if (year % 100 == 0 && year % 400 == 0) {
            numberOfDays = 29;
        }
        //Second check of leap year, divisable by 4 (if not 100)
        else if (year % 4 == 0) {
            numberOfDays = 29;
        }
        //If not a leap year then February is 28 days
        else {
            numberOfDays = 28;    
        }
    }
    //March
    if (month == 3) {
        numberOfDays = 31;
    }
    //April
    if (month == 4) {
        numberOfDays = 30;
    }
    //May
    if (month == 5) {
        numberOfDays = 31;
    }
    //June
    if (month == 6) {
        numberOfDays = 30;
    }
    //July
    if (month == 7) {
        numberOfDays = 31;
    }
    //August
    if (month == 8) {
        numberOfDays = 31;
    }
    //September
    if (month == 9) {
        numberOfDays = 30;
    }
    //October
    if (month == 10) {
        numberOfDays = 31;
    }
    //November
    if (month == 11) {
        numberOfDays = 30;
    }
    //December
    if (month == 12) {
        numberOfDays = 31;
    }
    //Return the amount of days for the user entered month
    return numberOfDays;
}
    
}
