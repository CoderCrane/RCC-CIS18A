/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.assignment2;

import java.util.Scanner;

/**
 *
 * River Crane, Last updated 1/9/20 9:15am
 */
public class FourIntegers {
    public static void main(String[] args) {
        
        int A, B, C, D;
        int maxValue;
        int minValue;
        int ansMin;
        int ansMax;
        
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter the first value: ");
        A = input.nextInt();
        
        System.out.print("Enter the second value: ");
        B = input.nextInt();
        
        System.out.print("Enter the third value: ");
        C = input.nextInt();
        
        System.out.print("Enter the fourth value: ");
        D = input.nextInt();
        
        //finding the minimum value
          if (A < B) {
              minValue = A;
          }
          else {
              minValue = B;
          }
          if (minValue < C) {
              ansMin = minValue;
          }
          else {
              ansMin = minValue = C;
          }
          if (minValue < D) {
              ansMin = minValue;
          }
          else {
              ansMin = minValue = D;
          }
           
        //finding the maximum value
   if (A > B) {
              maxValue = A;
          }
          else {
              maxValue = B;
          }
          if (maxValue > C) {
              ansMax = maxValue;
          }
          else {
              ansMax = maxValue = C;
          }
          if (maxValue > D) {
              ansMax = maxValue;
          }
          else {
              ansMax = maxValue = D;
          }
           
        System.out.printf("The values entered: %d, %d, %d, %d have a minimuim value %d and a maximum value %d", A, B, C, D, ansMin, ansMax);
    }
}
