/*
 * Please see AccountTest.java for programmer documentation.
 */
package com.mycompany.crane_river_accountbigdecimal;

// Fig. 7.8: Account.java
// Account class with a double instance variable BigDecimal and a constructor
// and deposit method that perform validation.
public class Account {
    private String name; // instance variable 
   private double BigDecimal; // instance variable 

   // Account constructor that receives two parameters  
   public Account(String name, double BigDecimal) 
   {
      this.name = name; // assign name to instance variable name

      // validate that the BigDecimal is greater than 0.0; if it's not,
      // instance variable BigDecimal keeps its default initial value of 0.0
      if (BigDecimal > 0.0) // if the BigDecimal is valid
         this.BigDecimal = BigDecimal; // assign it to instance variable balance
   }

   // method that deposits (adds) only a valid amount to the BigDecimal
   public void deposit(double depositAmount) 
   {      
      if (depositAmount > 0.0) // if the depositAmount is valid
         BigDecimal += depositAmount; // add it to the BigDecimal 
   }

   // method returns the account BigDecimal
   public double getBigDecimal()
   {
      return BigDecimal; 
   } 

   // method that sets the name
   public void setName(String name)
   {
      this.name = name; 
   } 

   // method that returns the name
   public String getName()
   {
      return name; 
   } 
} // end class Account
