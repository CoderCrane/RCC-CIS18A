/* Programmer Name: River Crane
 * Assignment Start: 1/20/20 12:56pm - 1:35pm, 1/21/20 7:36am - 9:03am
 * Assignment Completion: 1/21/20 9:03am
 * Total Hours for Assignment: 1 hr 48 min
 * Comments: At first I was confused on instructions, but with clarification I enoyed
 * the simplicity of learning about object oriented programming in java, making good
 * use of classes. For printed text being output, I've kept the word balance.
 * Although, all calculations/operations are done with BigDecimal. Thanks again for your help professor. 
 */

package com.mycompany.crane_river_accountbigdecimal;

import java.util.Scanner;


public class AccountTest {
    public static void main(String[] args) {
        Account account1 = new Account("Jane Green", 50.00);
        Account account2 = new Account("John Blue", -7.53);
        
        //display initial balance of each object
        System.out.printf("%s balance: $%.2f %n",
                account1.getName(), account1.getBigDecimal() );
         System.out.printf("%s balance: $%.2f %n",
                account2.getName(), account2.getBigDecimal() );
         
         Scanner input = new Scanner(System.in);
                 
         System.out.print("Enter deposit amount for account 1: "); //prompt
         double depositAmount = input.nextDouble(); //obtain user input
         System.out.printf("%nadding %.2f to account1's balance%n%n",
                 depositAmount);
         account1.deposit(depositAmount); // add to account1's balance
         
         // display balances
         System.out.printf("%s balance: $%.2f %n",
                 account1.getName(), account1.getBigDecimal() );
         System.out.printf("%s balance: $%.2f %n",
                 account2.getName(), account2.getBigDecimal() );
         
         System.out.print("Enter deposit amount for account2: "); // prompt
         depositAmount = input.nextDouble(); //obtain user input
         System.out.printf("%nadding %.2f to account2 balance%n%n",
                 depositAmount);
         account2.deposit(depositAmount); //add to account2 balance
         
         //display balances
         System.out.printf("%s balance: $%.2f %n",
                 account1.getName(), account1.getBigDecimal() );
         System.out.printf("%s balance: $%.2f %n",
                 account2.getName(), account2.getBigDecimal() );
         
    }
}
