/* Programmer Name: River Crane
 * Assignment Start: 1/15/20 10:01am - 11:40am, 6:45pm - 7:58pm, 1/16/20 8:32am - 11:55am, 4:30pm - 5:11pm
 * Assignment Completion: 1/16/20 5:11pm
 * Total Hours for Assignment: 7hr 40min
 * Comments: I had difficulty solving this the first day, but restarted the second day and was able to complete the assignment successfully.
             This project has helped improve my programming skills and understanding.
 */
package com.mycompany.crane_river_arraystatistics;

import java.util.Scanner;

public class ArrayStatistics {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        //Initializaition
        int arraySize; 
                
        //Requirement #1
          System.out.print("How many number of the type double do you want to store in your array? ");
        arraySize = input.nextInt();       
        
        //Requirement #2 - Create an array of doubles to hold the arraySize in step #1
        double[] arrayOfDoubles = new double[arraySize]; 
        
        //Requirement #3
        for(int i = 0; i < arraySize; i++) {
            System.out.printf("Enter a value #" + "%d: ", i + 1);
            arrayOfDoubles[i] = input.nextDouble();
        }
        
        //Requirement #4 - Find the min and max values of arrayOfDoubles, not a part of previous steps
        double maximumValue = Double.MIN_VALUE;//arrayOfDoubles[0];
        double minimumValue = Double.MAX_VALUE;//arrayOfDoubles[0];
        
        //Finding the minimum value from arrayOfDoubles 
        for (int i = 0; i < arrayOfDoubles.length; i++) {
            if (arrayOfDoubles[i] < minimumValue) minimumValue = arrayOfDoubles[i];
        }
        
        //Finding the maximum value from arrayOfDoubles
        for (int i = 0; i < arrayOfDoubles.length; i++) {
            if (arrayOfDoubles[i] > maximumValue) maximumValue = arrayOfDoubles[i];
        }
                
        //Requirement #5 - Find the average of the values stored in arrayOfDoubles
        double total = 0.0;
        for(int i = 0; i < arrayOfDoubles.length; i++) {
            total = total + arrayOfDoubles[i];
        }
        
        double average = total / arrayOfDoubles.length;
               
        //Requirement #6 - Based on a method using variable-length arguments,
        //compute the population standard deviation of values in the array.
        double finalPopulationStandardDeviation = populationStandardDeviation(arrayOfDoubles);
        
        //Requirement #7 - Based on a method using variable-length arguments,
        //compute the sample standard deviation of values in the array.
        double finalSampleStandardDeviation = sampleStandardDeviation(arrayOfDoubles);
        
        //Requirement #8 - Output all results in specified format using printf, just as assignment picture shows.
        System.out.printf("%nThe statistics for your user entered array is:%n-----------------------------------------------%n"
                + "%35s%10.3f%n%35s%10.3f%n%35s%10.3f%n%35s%10.3f%n%35s%10.3f%n", "Minimum:", minimumValue, "Maximum:", maximumValue, "Average:", average, "Standard deviation (population):", finalPopulationStandardDeviation, "Standard deviation (sample):", finalSampleStandardDeviation);
    }
    
    //Requirement #6 e.c. - Compute the population standard deviation of arrayOfDoubles, based on a method using variable-length arguments
    public static double populationStandardDeviation(double... arrayOfDoubles) {
        double total = 0.0;
        double populationStandardDeviation = 0.0;
        int length = arrayOfDoubles.length;
        
        for(double i : arrayOfDoubles) {
            total += i;
        }
        double meanValue = total / length;
        
        for(double i : arrayOfDoubles) {
            populationStandardDeviation += Math.pow(i - meanValue, 2);
        }
        return Math.sqrt(populationStandardDeviation / length);
    }
    
    //Requirement #7 e.c. - Compute the sample standard deviation of arrayOfDoubles, based on a method using variable-length arguments
    public static double sampleStandardDeviation(double... arrayOfDoubles) {
        double total = 0.0;
        double sampleStandardDeviation = 0.0;
        int length = arrayOfDoubles.length;
        
        for(double i : arrayOfDoubles) {
            total += i;
        }
        double meanValue = total / length;
        
        for(double i : arrayOfDoubles) {
            sampleStandardDeviation += Math.pow(i - meanValue, 2);
        }
        return Math.sqrt(sampleStandardDeviation / (length - 1));
    }
}