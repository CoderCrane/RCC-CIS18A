/*
 * Please see Assignment7Test.java for programmer documentation.
 */
package com.mycompany.crane_river_trafficsignal;

public class Assignment7 {
    
    //enum type called TrafficSignal.
    public enum TrafficSignal {
       RED,
       GREEN,
       YELLOW,
       WALK,
       DONT_WALK;
    }
    
    TrafficSignal event = TrafficSignal.GREEN;
    
    //go through a method cycle() which throws an exception, using a switch case to go through all traffic light colors and walk/dont walk.
    public void cycle() throws InterruptedException {
        switch (this.event) {
            case RED:
                System.out.printf("%s%n", "RED (20 seconds)");
                Thread.sleep(20000);
                this.event = TrafficSignal.WALK;
                break;
                
            case WALK:
                System.out.printf("%s%n", "WALK ");
                //using a for loop to display a countdown, like a real crosswalk.
                for (int i = 20; i > 0; i--) {
                    Thread.sleep(1000);
                    System.out.printf("%d%s%n", i, " seconds");
                }
                this.event = TrafficSignal.DONT_WALK;
                break;
                
            case DONT_WALK:
                System.out.printf("%s%n", "DONT WALK (Until WALK again, 55 seconds)"); //Although thread.sleep is set for 2 seconds,
                Thread.sleep(2000);                                                    // a person should not walk again until walk is displayed.
                this.event = TrafficSignal.GREEN;                                      //Walk will display in 55 seconds, making up 20 of green,
                break;                                                                 // 15 of yellow, and 20 of red.
                
            case GREEN:
                System.out.printf("%s%n", "GREEN (20 Seconds)");
                Thread.sleep(20000);
                this.event = TrafficSignal.YELLOW;
                break;
                
            case YELLOW:
                System.out.printf("%s%n", "YELLOW (15 seconds)");
                Thread.sleep(15000);
                this.event = TrafficSignal.RED;
                break;
        }
    }
    
}