/* Programmer Name: River Crane
 * Assignment Start: 1/22/20 7:31am - 9:15am
 * Assignment Completion: 1/22/20 9:15am
 * Total Hours for Assignment: 1 hour 44 minutes
 * Comments: I've made use of thread.sleep() to pause the program, and made additional
 * use of a for loop during the walk cycle to replicate a real timer for a crosswalk.
 * I found this assignment enjoyable and learned new programming techniques.
 */

package com.mycompany.crane_river_trafficsignal;


public class Assignment7Test {
    //string is final as the constants from enum being used in method cycle() will not change from their programmed purpose.
    public static void main(final String[] args) throws InterruptedException {
        final Assignment7 begin = new Assignment7();
        while (true) {
            begin.cycle();
        }
    }
}
