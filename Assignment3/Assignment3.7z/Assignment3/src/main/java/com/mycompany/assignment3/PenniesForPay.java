/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.assignment3;

import java.util.Scanner;

/**
 *
 * River Crane, Last updated 1/10/20 11:06am
 */
public class PenniesForPay {
       
    public static void main(String[] args) {
        
        int numDays;
        double penny = 0.01;
        double finalAmount = 0.0;

        Scanner input = new Scanner(System.in);

        System.out.print("For how many days will the pay double? ");
        numDays = input.nextInt();

        while (numDays < 1 || numDays > 45) {
            System.out.print("The number of days must be greater than 1 and less than 45. ");
            numDays = input.nextInt();
        }
        
        System.out.printf("%nDay               Total pay%n------------------------------------%n");
        
        for (int day = 1; day <= numDays; day++) {
            System.out.printf("%-3d", day);
            System.out.printf("               $%15.2f%n", penny);
            //System.out.printf("%3f%n", penny );
            
            finalAmount += penny;
            
            penny *= 2;   
        }
        System.out.printf("------------------------------------%nTotal             $%15.2f%n", finalAmount);
    }
    
    
}
