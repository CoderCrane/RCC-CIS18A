/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.assignment1;

import java.util.Scanner;

/**
 * Enter month, year, and total income to calculate monthly sales tax.
 * River Crane, last updated 1/8/2020 12:17pm
 */
public class MonthlySalesTax {
    public static void main(String[] args){
        
        final double STATE_SALES_TAX = .0675;
        final double COUNTY_SALES_TAX = .0310;
        double stateTax, countyTax;
        double totalIncome;
        double productSales;
        double totalTax;
        String month;
        int year;
        
        
        Scanner input = new Scanner(System.in);
        
        System.out.print("Please enter the month: "); //Prompt
        month = input.nextLine();
        
        System.out.print("Please enter the year: "); //Prompt
        year = input.nextInt();
        
        System.out.print("Please enter the total income: "); //Prompt
        totalIncome = input.nextDouble();
        
        stateTax = STATE_SALES_TAX * totalIncome;
        countyTax = COUNTY_SALES_TAX * totalIncome;
        totalTax = stateTax + countyTax;
        productSales = totalIncome / 1.0985;
        
        
        System.out.printf("%nMonth: %s %d%n---------------------------%nTotal Collected:   $ %.2f%nSales:             $ %.2f%nCounty Sales Tax:    $ %.2f%nState Sales Tax:    $ %.2f%nTotal Sales Tax:    $ %.2f%n", month, year, totalIncome, productSales, countyTax, stateTax, totalTax );
        
        
    }
}
