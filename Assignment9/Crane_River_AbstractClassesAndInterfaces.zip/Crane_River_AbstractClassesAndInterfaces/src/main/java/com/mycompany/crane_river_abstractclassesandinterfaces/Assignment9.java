/* Programmer Name: River Crane
 * Assignment Start: 1/30/20 9:17am - 12:00am
 * Assignment Completion: 1/30/20 
 * Total Hours for Assignment: 2 hours 43 minutes
 * Comments: None.
 */
package com.mycompany.crane_river_abstractclassesandinterfaces;

import java.util.Scanner;

public class Assignment9 {
    public static void main(String[] args) {
        int choice;
        Scanner input = new Scanner(System.in);
        Player1 player1 = new Player1();
        //using printf, display Player1 name, height, and width from abstract classes.
        System.out.printf("%s%s%n%s%s%n%s%s", "Name: ", player1.Name(), "Height: ", player1.Height(), "Width: ", player1.Width());
        
        //Making use of Movement interface for a run or walk action.
        System.out.printf("%n%s", "Do you want to walk or run?(1 = walk, 2 = run) ");
        choice = input.nextInt();
        
        while (choice < 1 || choice > 2) {
            System.out.printf("%s", "Please enter 1 or 2. ");
            choice = input.nextInt();
        }
        
        if (choice == 1) {
            System.out.printf("--------------------%n%s%s%s", "You walk at a speed of: ", player1.Walk(), "!");
        }
        if (choice == 2) {
            System.out.printf("--------------------%n%s%s%s", "You run at a speed of: ", player1.Run(), "!");
        }
        
    }
}
