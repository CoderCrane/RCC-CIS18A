package com.mycompany.crane_river_abstractclassesandinterfaces;

// Abstract class GameAssets
public abstract class GameAssets {
// abstract classes which Player1 will inherit and do things with.
    public abstract String Name();
    public abstract int Height();
    public abstract int Width();
}
