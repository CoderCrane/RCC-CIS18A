package com.mycompany.crane_river_abstractclassesandinterfaces;

// Class Player1 will extend abstract class GameAssets
public class Player1 extends GameAssets implements Movement {
// Name, height, and width of abstract class GameAssets are used and defined so data can be displayed in main.
    @Override
    public String Name() {
        
        return String.format("%s", "Steve");
        
    }
    
    @Override
    public int Height() {
        return 5;
    }
    
    @Override
    public int Width() {
        return 3;
    }

    @Override
    public double Walk() {
        return 7.8;
    }

    @Override
    public double Run() {
        return 10.5;
    }
    
}
