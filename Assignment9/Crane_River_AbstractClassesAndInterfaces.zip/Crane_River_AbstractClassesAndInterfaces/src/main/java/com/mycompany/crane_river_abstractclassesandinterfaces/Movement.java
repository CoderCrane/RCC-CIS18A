package com.mycompany.crane_river_abstractclassesandinterfaces;

public interface Movement {
    // interface for player1 movement, walking and running.
    double Walk();
    double Run();
}
